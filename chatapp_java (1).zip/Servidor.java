import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class Servidor {
    public static void main(String[] args) {
        ChatServer.getInstance().start(12345);
    }
}

class ChatServer {
    private static ChatServer instance;
    private ServerSocket serverSocket;
    private final Map<String, ClientHandler> clients = new ConcurrentHashMap<>();

    private ChatServer() {}

    public static synchronized ChatServer getInstance() {
        if (instance == null) instance = new ChatServer();
        return instance;
    }

    public void start(int port) {
        try {
            serverSocket = new ServerSocket(port);
            System.out.println("Servidor iniciado en el puerto " + port);

            while (true) {
                Socket socket = serverSocket.accept();
                new Thread(new ClientHandler(socket, this)).start();
            }
        } catch (IOException e) {
            System.err.println("Error al iniciar el servidor: " + e.getMessage());
        }
    }

    public boolean registerUser(String username, ClientHandler handler) {
        if (clients.containsKey(username)) return false;
        clients.put(username, handler);
        broadcast("✅ " + username + " se ha conectado.");
        updateUserList();
        return true;
    }

    public void removeUser(String username) {
        clients.remove(username);
        broadcast("⚠️ " + username + " se ha desconectado.");
        updateUserList();
    }

    public void broadcast(String message) {
        for (ClientHandler handler : clients.values()) {
            handler.sendMessage(message);
        }
    }

    public void sendPrivateMessage(String fromUser, String toUser, String message) {
        ClientHandler recipient = clients.get(toUser);
        if (recipient != null) {
            recipient.sendMessage("🔒 (Privado de " + fromUser + "): " + message);
        }
    }

    public void updateUserList() {
        String users = Protocolo.USERS + String.join(",", clients.keySet());
        broadcast(users);
    }

    public boolean userExists(String username) {
        return clients.containsKey(username);
    }
}

class ClientHandler implements Runnable {
    private final Socket socket;
    private final ChatServer server;
    private PrintWriter out;
    private BufferedReader in;
    private String username;

    public ClientHandler(Socket socket, ChatServer server) {
        this.socket = socket;
        this.server = server;
    }

    public void sendMessage(String message) {
        if (out != null) out.println(message);
    }

    private void processCommand(String line) {
        if (line.startsWith(Protocolo.LOGIN + " ")) {
            String name = Protocolo.sanitizar(line.substring(7));
            if (name.isBlank() || !server.registerUser(name, this)) {
                sendMessage("❌ Nombre de usuario inválido o ya en uso.");
            } else {
                username = name;
                sendMessage("🎉 Bienvenido, " + username + "!");
            }
        } else if (line.startsWith(Protocolo.MSG + " ")) {
            if (username == null) return;
            String message = Protocolo.reemplazarEmojis(Protocolo.sanitizar(line.substring(5)));
            server.broadcast("💬 " + username + ": " + message);
        } else if (line.startsWith(Protocolo.PRIVADO + " ")) {
            if (username == null) return;
            Map<String, String> data = Protocolo.parsearPrivado(line);
            if (!data.containsKey("destinatario") || !server.userExists(data.get("destinatario"))) {
                sendMessage("❌ Usuario no válido para mensaje privado.");
            } else {
                String msg = Protocolo.reemplazarEmojis(Protocolo.sanitizar(data.get("mensaje")));
                server.sendPrivateMessage(username, data.get("destinatario"), msg);
            }
        } else if (line.startsWith(Protocolo.EMOJI + " ")) {
            if (username == null) return;
            String emoji = Protocolo.EMOJI_MAP.getOrDefault(line.substring(7).trim(), "❓");
            server.broadcast("😄 " + username + " envió un emoji: " + emoji);
        } else if (line.equalsIgnoreCase(Protocolo.SALIR)) {
            sendMessage("👋 Hasta pronto!");
            cleanup();
        } else {
            sendMessage("❓ Comando no reconocido.");
        }
    }

    private void cleanup() {
        try {
            if (username != null) server.removeUser(username);
            if (socket != null && !socket.isClosed()) socket.close();
        } catch (IOException e) {
            System.err.println("Error al cerrar conexión: " + e.getMessage());
        }
    }

    @Override
    public void run() {
        try {
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            sendMessage("🔐 Usa /login [nombre] para ingresar.");

            String line;
            while ((line = in.readLine()) != null) {
                processCommand(line.trim());
            }

        } catch (IOException e) {
            System.err.println("Error en la conexión del cliente: " + e.getMessage());
        } finally {
            cleanup();
        }
    }
}
