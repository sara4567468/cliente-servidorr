import java.util.HashMap;
import java.util.Map;

public class Protocolo {
    public static final String LOGIN = "/login";
    public static final String MSG = "/msg";
    public static final String PRIVADO = "/privado";
    public static final String EMOJI = "/emoji";
    public static final String SALIR = "/salir";
    public static final String USERS = "USERS:";

    public static final Map<String, String> EMOJI_MAP = Map.of(
        ":smile:", "😊",
        ":fire:", "🔥",
        ":heart:", "❤️",
        ":thumbs:", "👍"
    );

    public static boolean esComando(String linea) {
        return linea.startsWith("/");
    }

    public static String reemplazarEmojis(String mensaje) {
        for (var entry : EMOJI_MAP.entrySet()) {
            mensaje = mensaje.replace(entry.getKey(), entry.getValue());
        }
        return mensaje;
    }

    public static String sanitizar(String entrada) {
        return entrada.replaceAll("[;<>"'&]", "");
    }

    public static Map<String, String> parsearPrivado(String linea) {
        String[] partes = linea.split(" ", 3);
        Map<String, String> resultado = new HashMap<>();
        if (partes.length == 3) {
            resultado.put("destinatario", partes[1]);
            resultado.put("mensaje", partes[2]);
        }
        return resultado;
    }
}
